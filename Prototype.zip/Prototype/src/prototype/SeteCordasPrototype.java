/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author JéssicaFerreira
 */
public class SeteCordasPrototype extends ViolaoPrototype{
    protected SeteCordasPrototype(SeteCordasPrototype seteCordasPrototype) {
        this.valorCompra = seteCordasPrototype.getValorCompra();
    }
 
    public SeteCordasPrototype() {
        valorCompra = 0.0;
    }
 
    @Override
    public String exibirInfo() {
        return "Modelo: Sete Cordas\nEsse é o violão brasileiro! É indicado para acompanhar gêneros como o choro e o samba\nModelo acústico suas cordas na maioria das vezes são feitas de nylon.\nÉ indicado para iniciantes graças à sua leveza e maciez.\nSeu diferencial está na sétima corda, que costuma ser afinada de maneira mais grave que as outras seis. Isso exige um conhecimento do músico que for tocá-lo.\n" + "Valor: R$"
                + getValorCompra();
    }

    @Override
    public ViolaoPrototype clonar() {
       return new SeteCordasPrototype (this);
    }
 
    
}
