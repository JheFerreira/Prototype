/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author JéssicaFerreira
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
       ClassicoPrototype prototipoClassico = new ClassicoPrototype();
       ClassicoPrototype classicoNovo= (ClassicoPrototype) prototipoClassico.clonar();
       classicoNovo.setValorCompra(100);
       System.out.println(classicoNovo.exibirInfo());
       
       DozeCordasPrototype prototipoDozeCordas = new DozeCordasPrototype();
       DozeCordasPrototype dozeCordasNovo= (DozeCordasPrototype) prototipoDozeCordas.clonar();
       dozeCordasNovo.setValorCompra(200);
       System.out.println(dozeCordasNovo.exibirInfo());
       
       
       DuploZeroPrototype prototipoDuploZero = new DuploZeroPrototype();
       DuploZeroPrototype duploZeroNovo= (DuploZeroPrototype) prototipoDuploZero.clonar();
       duploZeroNovo.setValorCompra(300);
       System.out.println(duploZeroNovo.exibirInfo());
       
       FletPrototype prototipoFlet = new FletPrototype();
       FletPrototype fletNovo= (FletPrototype) prototipoFlet.clonar();
       fletNovo.setValorCompra(400);
       System.out.println(fletNovo.exibirInfo());
       
       FolkPrototype prototipoFolk = new FolkPrototype();
       FolkPrototype folkNovo= (FolkPrototype) prototipoFolk.clonar();
       folkNovo.setValorCompra(500);
       System.out.println(folkNovo.exibirInfo());
       
       JumboPrototype prototipoJumbo = new JumboPrototype();
       JumboPrototype jumboNovo= (JumboPrototype) prototipoJumbo.clonar();
       jumboNovo.setValorCompra(1000);
       System.out.println(jumboNovo.exibirInfo());
       
       SeteCordasPrototype prototipoSeteCordas = new SeteCordasPrototype();
       SeteCordasPrototype seteCordasNovo= (SeteCordasPrototype) prototipoSeteCordas.clonar();
       seteCordasNovo.setValorCompra(100);
       System.out.println(seteCordasNovo.exibirInfo());
       
       TriploZeroPrototype prototipoTriploZero = new TriploZeroPrototype();
       TriploZeroPrototype triploZeroNovo= (TriploZeroPrototype) prototipoTriploZero.clonar();
       triploZeroNovo.setValorCompra(100);
       System.out.println(triploZeroNovo.exibirInfo());
       
       
       ZeroPrototype prototipoZero = new ZeroPrototype();
       ZeroPrototype zeroNovo= (ZeroPrototype) prototipoZero.clonar();
       zeroNovo.setValorCompra(100);
       System.out.println(zeroNovo.exibirInfo());
       
       
       

        
    }
    
}

    
    

