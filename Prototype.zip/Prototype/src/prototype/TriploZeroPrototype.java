/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author JéssicaFerreira
 */
public class TriploZeroPrototype extends ViolaoPrototype {
    
   
 
    protected TriploZeroPrototype(TriploZeroPrototype triplozeroPrototype) {
        this.valorCompra = triplozeroPrototype.getValorCompra();
    }
 
    public TriploZeroPrototype() {
        valorCompra = 0.0;
    }
 
    @Override
    public String exibirInfo() {
        return "Modelo: TriploZero\nEsse violão é categorizado como Parlor\nCom estruturas menores e sendo mais indicado para uso casual e não tanto profissional.\nEntre três tipos, o Triplo Zero possui tamanho intermediário e gera um timbre mais peculiar.\n" + "Valor: R$"
                + getValorCompra();
    }

    @Override
    public ViolaoPrototype clonar() {
       return new TriploZeroPrototype (this);
    } 
    
}
