/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author JéssicaFerreira
 */
public class JumboPrototype extends ViolaoPrototype {

   protected JumboPrototype(JumboPrototype jumboPrototype) {
        this.valorCompra = jumboPrototype.getValorCompra();
    }
 
    public JumboPrototype() {
        valorCompra = 0.0;
    }
 
    @Override
    public String exibirInfo() {
        return "Modelo: Jumbo\nViolão do  Elvis Presley!!\nPossui corpo largo e a base mais arredondada.\nModelos eletroacústicos e com cordas de aço.\n" + "Valor: R$"
                + getValorCompra();
    }

    @Override
    public ViolaoPrototype clonar() {
       return new JumboPrototype (this);
    }
 
    
}
