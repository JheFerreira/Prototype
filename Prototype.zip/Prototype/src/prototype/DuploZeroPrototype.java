/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author JéssicaFerreira
 */
public class DuploZeroPrototype extends ViolaoPrototype {
    
   
 
    protected DuploZeroPrototype(DuploZeroPrototype duplozeroPrototype) {
        this.valorCompra = duplozeroPrototype.getValorCompra();
    }
 
    public DuploZeroPrototype() {
        valorCompra = 0.0;
    }
 
    @Override
    public String exibirInfo() {
        return "Modelo: Duplo Zero\nEsse violão é categorizado como Parlor;\nCom estruturas menores e sendo mais indicado para uso casual e não tanto profissional.\nEntre três tipos, o Duplo Zero é um pouco maior, apresentando uma boa sonoridade e sendo indicado para técnicas de Fingerstyle.\n" + "Valor: R$"
                + getValorCompra();
    }

    @Override
    public ViolaoPrototype clonar() {
       return new DuploZeroPrototype (this);
    } 
    
}
