/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author JéssicaFerreira
 */
public class DozeCordasPrototype extends ViolaoPrototype {
    
   
 
    protected DozeCordasPrototype(DozeCordasPrototype dozeCordasPrototype) {
        this.valorCompra = dozeCordasPrototype.getValorCompra();
    }
 
    public DozeCordasPrototype() {
        valorCompra = 0.0;
    }
 
    @Override
    public String exibirInfo() {
        return "Modelo: DozeCordas\nApresenta o dobro de cordas do que o Clássico (6 cordas).\nEssas cordas são agrupadas em duplas(metade delas afinadas com uma oitava acima).\nEsse tipo apresenta ressonância plena e exige técnica e prática para poder pressionar duas cordas simultaneamente.\n"+"Valor:R$"
                + getValorCompra();
    }

    @Override
    public ViolaoPrototype clonar() {
       return new DozeCordasPrototype (this);
    } 
    
}
