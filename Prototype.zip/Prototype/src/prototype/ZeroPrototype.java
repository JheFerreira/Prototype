/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author JéssicaFerreira
 */
public class ZeroPrototype extends ViolaoPrototype {
    
   
 
    protected ZeroPrototype(ZeroPrototype zeroPrototype) {
        this.valorCompra = zeroPrototype.getValorCompra();
    }
 
    public ZeroPrototype() {
        valorCompra = 0.0;
    }
 
    @Override
    public String exibirInfo() {
        return "Modelo: Zero\nEsse violão é categorizado como Parlor.\nCom estruturas menores e sendo mais indicado para uso casual e não tanto profissional.\nEntre três tipos, o Violão Zero é o menor, com uma estrutura confortável para tocar por bastante tempo.\n" + "Valor: R$"
                + getValorCompra();
    }

    @Override
    public ViolaoPrototype clonar() {
       return new ZeroPrototype (this);
    } 
    
}
