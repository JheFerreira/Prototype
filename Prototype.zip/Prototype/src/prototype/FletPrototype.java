/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author JéssicaFerreira
 */
public class FletPrototype extends ViolaoPrototype {
    
   
 
    protected FletPrototype(FletPrototype fletPrototype) {
        this.valorCompra = fletPrototype.getValorCompra();
    }
 
    public FletPrototype() {
        valorCompra = 0.0;
    }
 
    @Override
    public String exibirInfo() {
        return "Modelo: Flet\nPlano sua caixa acústica é bastante fina! O violão Flet é muito utilizado por músicos profissionais e na maioria dos casos é tocado com cordas de Nylon.\nO timbre gerado por esse tipo de violão é mais suave.\nVale lembrar que, por ser encontrado quase sempre em modelos elétricos, precisa de amplificação.\n" + "Valor: R$"
                + getValorCompra();
    }

    @Override
    public ViolaoPrototype clonar() {
        return new FletPrototype (this);
    }
 
   
}
    

