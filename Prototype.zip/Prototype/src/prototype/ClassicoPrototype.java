/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author JéssicaFerreira
 */
public class ClassicoPrototype extends ViolaoPrototype {
    
   
 
    protected ClassicoPrototype(ClassicoPrototype classicoPrototype) {
        this.valorCompra = classicoPrototype.getValorCompra();
    }
 
    public ClassicoPrototype() {
        valorCompra = 0.0;
    }
 
    @Override
    public String exibirInfo() {
        return "Modelo: Clássico\nSeis Cordas de Nylon\nÉ indicado para iniciantes graças à sua leveza e maciez!\n" + "Valor: R$"
                + getValorCompra();
    }

    @Override
    public ViolaoPrototype clonar() {
       return new ClassicoPrototype (this);
    }
 
   
 
}
    

