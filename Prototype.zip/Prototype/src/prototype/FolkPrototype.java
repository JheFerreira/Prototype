/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

/**
 *
 * @author JéssicaFerreira
 */
public class FolkPrototype extends ViolaoPrototype {
    
   
 
    protected FolkPrototype(FolkPrototype folkPrototype) {
        this.valorCompra = folkPrototype.getValorCompra();
    }
 
    public FolkPrototype() {
        valorCompra = 0.0;
    }
 
    @Override
    public String exibirInfo() {
        return "Modelo: Folk \nEsse modelo possui o corpo maior e mais “acinturado”; \nOs violões do tipo Folk também são bastante populares entre os músicos.\nA maioria dos modelos desse tipo de violão funcionam com a utilização de cordas de aço, podendo ser elétricos ou eletroacústicos.\nEsse tipo de violão é o mais indicado para gêneros como Pop e Rock, já que gera um som mais encorpado, com timbre diferenciado.\n" + "Valor: R$"
                + getValorCompra();
    }

    @Override
    public ViolaoPrototype clonar() {
       return new FolkPrototype (this);
    } 
    
}
